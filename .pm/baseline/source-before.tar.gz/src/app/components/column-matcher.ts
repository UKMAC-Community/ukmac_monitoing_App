import {
  afterEveryRender,
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  ElementRef,
  inject,
  input,
  linkedSignal,
  output,
  signal,
} from '@angular/core';

import type { Column } from '../core/models';
import type { FileColumn } from '../excel/excel-template';
import { columnLabel } from '../sheet/columns';
import { Icon } from './icon';

type Side = 'file' | 'table';
type Mapping = Record<string, number>;

/** A pointer moved this far (px) is dragging, not clicking. */
const DRAG_FROM = 5;

/**
 * The file's columns beside the table's, a line between each pair matched (as a database import wizard
 * does): drag from one to the other, or click one then the other; click a line to take it off.
 * `mapping` is each table column's key → the file's column (its worksheet position) that fills it.
 */
@Component({
  selector: 'app-column-matcher',
  imports: [Icon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { '(keydown.escape)': 'picked.set(null)' },
  template: `
    <section class="matcher">
      <header class="bar">
        <span class="count">{{ count() }} of {{ targets().length }} matched</span>
        <span class="grow"></span>
        <button type="button" class="btn btn-plain btn-sm" (click)="auto.emit()"><app-icon name="refresh" /> Match by name</button>
        <button type="button" class="btn btn-plain btn-sm" [disabled]="!count()" (click)="clear()">Clear</button>
      </header>

      <div class="diagram">
        <div class="panel">
          <h4>Columns in the file</h4>
          <ul>
            @for (file of fileColumns(); track file.position) {
              <li
                class="item"
                [attr.data-pos]="file.position"
                [class.on]="used().has(file.position)"
                [class.picked]="picked()?.side === 'file' && picked()?.id === file.position"
                [title]="file.sample ? file.header + ' (for example: ' + file.sample + ')' : file.header"
                (pointerdown)="down($event, 'file', file.position)"
              >
                <span class="name">{{ file.header }}</span>
              </li>
            }
          </ul>
        </div>

        <svg class="lines" aria-hidden="true">
          @for (line of lines(); track line.key) {
            <path class="hit" [attr.d]="line.d" (click)="unmatch(line.key)" />
            <path class="line" [attr.d]="line.d" />
            <circle class="dot" cx="0" [attr.cy]="line.y1" r="3" />
            <circle class="dot" [attr.cx]="coords().w" [attr.cy]="line.y2" r="3" />
          }
          @if (dragPath(); as d) {
            <path class="line is-drag" [attr.d]="d" />
          }
        </svg>

        <div class="panel">
          <h4>Columns of {{ tableTitle() }}</h4>
          <ul>
            @for (column of targets(); track column.key) {
              <li
                class="item"
                [attr.data-key]="column.key"
                [class.on]="local()[column.key] != null"
                [class.picked]="picked()?.side === 'table' && picked()?.id === column.key"
                [title]="label(column)"
                (pointerdown)="down($event, 'table', column.key)"
              >
                <span class="name">{{ label(column) }}</span>
                @if (column.required) {
                  <span class="req" title="Every row needs this column">*</span>
                }
              </li>
            }
          </ul>
        </div>
      </div>
      <p class="muted hint">Drag a column of the file onto a column of the table, or click one then the other. Click a line to take it off.</p>
    </section>
  `,
  styles: `
    :host { display: flex; flex-direction: column; min-height: 0; }
    .matcher { flex: 1; min-height: 0; display: flex; flex-direction: column; border: var(--hairline) solid var(--border); border-radius: var(--radius-md); background: var(--surface-solid); padding: 8px 14px 10px; }
    .bar { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
        .count { font-size: 0.875rem; font-weight: 600; }
    .grow { flex: 1; }
    .hint { margin: 8px 0 0; text-align: center; font-size: 0.75rem; }
    .diagram { display: grid; grid-template-columns: minmax(0, 270px) 110px minmax(0, 270px); justify-content: center; flex: 1; min-height: 0; overflow: auto; margin-top: 8px; align-items: start; }
    .panel { border: var(--hairline) solid var(--border-strong); border-radius: var(--radius-sm); background: var(--surface-solid); overflow: hidden; }
    .panel h4 { position: sticky; top: 0; z-index: 1; margin: 0; padding: 5px 10px; background: var(--fill); border-bottom: var(--hairline) solid var(--border); font-size: 0.75rem; font-weight: 600; color: var(--text-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .panel ul { list-style: none; margin: 0; padding: 0; }
    .item { display: flex; align-items: center; gap: 6px; min-width: 0; padding: 3px 10px; font-size: 0.8125rem; line-height: 1.3; cursor: pointer; user-select: none; touch-action: none; transition: background-color var(--dur-fast) var(--ease); }
    .item + .item { border-top: var(--hairline) solid var(--border); }
    .item:hover { background: var(--surface-hover); }
    .item.on { background: var(--accent-soft); }
    .item.picked { outline: 2px solid var(--accent); outline-offset: -2px; }
    .name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .req { flex: none; margin-left: auto; font-weight: 700; color: var(--danger); }
    .lines { display: block; width: 100%; height: 100%; min-height: 1px; overflow: visible; }
    .line { fill: none; stroke: var(--text); stroke-width: 1.5; pointer-events: none; }
    .line.is-drag { stroke: var(--accent); stroke-dasharray: 5 4; }
    .hit { fill: none; stroke: transparent; stroke-width: 12; cursor: pointer; }
    .hit:hover + .line { stroke-width: 3; stroke: var(--danger); }
    .dot { fill: var(--text); pointer-events: none; }
  `,
})
export class ColumnMatcher {
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef);

  readonly fileColumns = input.required<FileColumn[]>();
  readonly targets = input.required<Column[]>();
  /** Each table column's key → the file column (worksheet position) that fills it. */
  readonly mapping = input.required<Mapping>();
  readonly tableTitle = input('this table');
  readonly mappingChange = output<Mapping>();
  /** "Match by name": the matches go back to what the names say. */
  readonly auto = output<void>();

  /** What is shown at once; the parent's answer (the file read again with it) replaces it when it comes. */
  readonly local = linkedSignal<Mapping>(() => this.mapping());
  readonly picked = signal<{ side: Side; id: string | number } | null>(null);
  /** The line being dragged: where the pointer is, in the lines' own coordinates. */
  private readonly drag = signal<{ side: Side; id: string | number; x: number; y: number } | null>(null);
  /** Where each column's row sits (its middle, from the lines' top) and how wide the lines' space is. */
  readonly coords = signal<{ w: number; file: Record<number, number>; table: Record<string, number> }>({ w: 0, file: {}, table: {} });

  readonly count = computed(() => Object.keys(this.local()).length);
  readonly used = computed(() => new Set(Object.values(this.local())));
  readonly lines = computed(() => {
    const { w, file, table } = this.coords();
    const out: { key: string; d: string; y1: number; y2: number }[] = [];
    for (const [key, position] of Object.entries(this.local())) {
      const y1 = file[position];
      const y2 = table[key];
      if (y1 === undefined || y2 === undefined) continue;
      out.push({ key, d: curve(0, y1, w, y2), y1, y2 });
    }
    return out;
  });
  readonly dragPath = computed(() => {
    const drag = this.drag();
    if (!drag) return null;
    const { w, file, table } = this.coords();
    if (drag.side === 'file') {
      const y = file[drag.id as number];
      return y === undefined ? null : curve(0, y, drag.x, drag.y);
    }
    const y = table[drag.id as string];
    return y === undefined ? null : curve(w, y, drag.x, drag.y);
  });

  constructor() {
    // The lines follow the rows: measured after each draw, and kept only when something moved.
    afterEveryRender(() => this.measure());
    const destroy = inject(DestroyRef);
    destroy.onDestroy(() => this.stopDrag?.());
  }

  label(column: Column) {
    return columnLabel(column);
  }

  // ---------------------------------------------------------------- matches

  /** The file column `position` fills the table column `key` (null: none). A file column fills one only. */
  private set(key: string, position: number | null) {
    const next = { ...this.local() };
    if (position === null) {
      delete next[key];
    } else {
      for (const other of Object.keys(next)) if (next[other] === position) delete next[other];
      next[key] = position;
    }
    this.local.set(next);
    this.mappingChange.emit(next);
  }

  unmatch(key: string) {
    this.set(key, null);
  }

  clear() {
    this.local.set({});
    this.mappingChange.emit({});
  }

  // ------------------------------------------------------------ the pointer

  private stopDrag: (() => void) | null = null;

  /** A press on a column: dragged to another side's column it makes the match; not moved, it's a click. */
  down(event: PointerEvent, side: Side, id: string | number) {
    if (event.button !== 0) return;
    event.preventDefault();
    const start = { x: event.clientX, y: event.clientY, moved: false };
    const move = (e: PointerEvent) => {
      if (!start.moved && Math.hypot(e.clientX - start.x, e.clientY - start.y) < DRAG_FROM) return;
      start.moved = true;
      const box = this.linesBox();
      if (box) this.drag.set({ side, id, x: e.clientX - box.left, y: e.clientY - box.top });
    };
    const up = (e: PointerEvent) => {
      this.stopDrag?.();
      if (!start.moved) return this.click(side, id);
      const over = document.elementFromPoint(e.clientX, e.clientY)?.closest<HTMLElement>('[data-pos],[data-key]');
      if (!over) return;
      if (side === 'file' && over.dataset['key']) this.set(over.dataset['key'], id as number);
      if (side === 'table' && over.dataset['pos']) this.set(id as string, Number(over.dataset['pos']));
    };
    this.stopDrag = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      window.removeEventListener('pointercancel', up);
      this.drag.set(null);
      this.stopDrag = null;
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
    window.addEventListener('pointercancel', up);
  }

  /** Clicked: the first column is held, the next one on the other side is its match. */
  private click(side: Side, id: string | number) {
    const held = this.picked();
    if (!held || held.side === side) {
      this.picked.set(held && held.side === side && held.id === id ? null : { side, id });
      return;
    }
    this.picked.set(null);
    if (side === 'table') this.set(id as string, held.id as number);
    else this.set(held.id as string, id as number);
  }

  private linesBox() {
    return this.host.nativeElement.querySelector('svg.lines')?.getBoundingClientRect() ?? null;
  }

  private measure() {
    const box = this.linesBox();
    if (!box) return;
    const file: Record<number, number> = {};
    const table: Record<string, number> = {};
    const root = this.host.nativeElement;
    root.querySelectorAll<HTMLElement>('[data-pos]').forEach((element) => {
      const rect = element.getBoundingClientRect();
      file[Number(element.dataset['pos'])] = Math.round(rect.top + rect.height / 2 - box.top);
    });
    root.querySelectorAll<HTMLElement>('[data-key]').forEach((element) => {
      const rect = element.getBoundingClientRect();
      table[element.dataset['key']!] = Math.round(rect.top + rect.height / 2 - box.top);
    });
    const next = { w: Math.round(box.width), file, table };
    if (JSON.stringify(next) !== JSON.stringify(this.coords())) this.coords.set(next);
  }
}

/** A line from one side to the other, leaving and arriving level. */
function curve(x1: number, y1: number, x2: number, y2: number) {
  const middle = (x1 + x2) / 2;
  return `M ${x1} ${y1} C ${middle} ${y1}, ${middle} ${y2}, ${x2} ${y2}`;
}

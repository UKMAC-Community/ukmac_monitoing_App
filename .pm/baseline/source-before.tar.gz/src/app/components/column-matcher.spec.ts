import { TestBed } from '@angular/core/testing';

import type { Column } from '../core/models';
import type { FileColumn } from '../excel/excel-template';
import { ColumnMatcher } from './column-matcher';

const col = (key: string, name: string, extra: Partial<Column> = {}): Column => ({ key, name, type: 'text', ...extra });

const targets = [col('c1', 'Variety name', { required: true }), col('c2', 'Origin'), col('c3', 'Description')];
const fileColumns: FileColumn[] = [
  { position: 1, header: 'Name of kind *', sample: 'Thai Bird Eye' },
  { position: 2, header: 'Where from', sample: 'Thailand' },
  { position: 4, header: 'Notes', sample: '' }, // positions skip empty header cells
];

/** A press and release without moving: a click, as the matcher sees it. */
function press(element: Element) {
  element.dispatchEvent(new MouseEvent('pointerdown', { button: 0, clientX: 5, clientY: 5, bubbles: true }));
  window.dispatchEvent(new MouseEvent('pointerup', { button: 0, clientX: 5, clientY: 5 }));
}

describe('ColumnMatcher', () => {
  function setup(mapping: Record<string, number> = {}) {
    const fixture = TestBed.createComponent(ColumnMatcher);
    fixture.componentRef.setInput('fileColumns', fileColumns);
    fixture.componentRef.setInput('targets', targets);
    fixture.componentRef.setInput('mapping', mapping);
    fixture.componentRef.setInput('tableTitle', 'Chili Varieties');
    const changes: Record<string, number>[] = [];
    fixture.componentInstance.mappingChange.subscribe((map) => changes.push(map));
    fixture.detectChanges();
    const el: HTMLElement = fixture.nativeElement;
    return { fixture, el, changes };
  }

  it('lists the file\'s columns and the table\'s, and says how many are matched', () => {
    const { el } = setup({ c2: 2 });
    expect([...el.querySelectorAll('[data-pos] .name')].map((item) => item.textContent)).toEqual(['Name of kind *', 'Where from', 'Notes']);
    expect([...el.querySelectorAll('[data-key] .name')].map((item) => item.textContent)).toEqual(['Variety name', 'Origin', 'Description']);
    expect(el.querySelector('.count')?.textContent).toContain('1 of 3 matched');
    expect(el.querySelector('[data-key="c1"] .req')).toBeTruthy();
  });

  it('matches a file column to a table column by clicking one, then the other', () => {
    const { fixture, el, changes } = setup();
    press(el.querySelector('[data-pos="1"]')!);
    fixture.detectChanges();
    expect(el.querySelector('[data-pos="1"]')!.classList).toContain('picked');
    press(el.querySelector('[data-key="c1"]')!);
    fixture.detectChanges();
    expect(changes.at(-1)).toEqual({ c1: 1 });
    expect(el.querySelector('.count')?.textContent).toContain('1 of 3');
  });

  it('lets a file column fill only one table column: the second match takes it off the first', () => {
    const { fixture, el, changes } = setup({ c1: 1 });
    press(el.querySelector('[data-key="c3"]')!); // a table column first, then the file column
    press(el.querySelector('[data-pos="1"]')!);
    fixture.detectChanges();
    expect(changes.at(-1)).toEqual({ c3: 1 });
  });

  it('takes a match off by clicking its line, and clears them all', () => {
    const { fixture, el, changes } = setup({ c1: 1, c2: 2 });
    // The lines are drawn where the rows sit; a jsdom page has no layout, so give the rows places to be.
    fixture.componentInstance.coords.set({ w: 100, file: { 1: 10, 2: 40, 4: 70 }, table: { c1: 10, c2: 40, c3: 70 } });
    fixture.detectChanges();
    expect(el.querySelectorAll('path.line').length).toBe(2);
    (el.querySelector('path.hit') as SVGPathElement).dispatchEvent(new MouseEvent('click', { bubbles: true }));
    fixture.detectChanges();
    expect(changes.at(-1)).toEqual({ c2: 2 });
    [...el.querySelectorAll('button')].find((button) => button.textContent?.includes('Clear'))!.click();
    fixture.detectChanges();
    expect(changes.at(-1)).toEqual({});
    expect(el.querySelector('.count')?.textContent).toContain('0 of 3');
  });
});

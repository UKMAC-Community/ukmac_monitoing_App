import { TestBed } from '@angular/core/testing';

import type { Column } from '../core/models';
import { loadExcel } from '../excel/exceljs';
import { makeSheet } from '../test-helpers';
import { ImportDialog } from './import-dialog';

// jsdom has no native <dialog> methods; the Modal only needs them to open and close.
if (!HTMLDialogElement.prototype.showModal) {
  HTMLDialogElement.prototype.showModal = function showModal() {
    this.setAttribute('open', '');
  };
  HTMLDialogElement.prototype.close = function close() {
    this.removeAttribute('open');
  };
}

const col = (key: string, name: string, extra: Partial<Column> = {}): Column => ({ key, name, type: 'text', ...extra });

/** A Chili Varieties-like table (Variety name required) and a nursery-batches file that lacks that column. */
async function nurseryFile() {
  const Excel = await loadExcel();
  const book = new Excel.Workbook();
  const data = book.addWorksheet('Nursery Batches');
  data.addRow(['Batch #', 'Total number', 'Supplier', 'Note']);
  data.addRow(['B-01', 500, 'Kampot Seeds', 'first sowing']);
  data.addRow(['B-02', 320, 'Kampot Seeds', '']);
  return (await book.xlsx.writeBuffer()) as ArrayBuffer;
}

describe('ImportDialog with a file that lacks a required column', () => {
  const varieties = makeSheet(7, 'Chili Varieties', [
    col('c1', 'Variety name', { required: true }),
    col('c2', 'Supplier'),
    col('c3', 'Note'),
  ]);

  async function open() {
    const fixture = TestBed.createComponent(ImportDialog);
    fixture.componentRef.setInput('sheet', varieties);
    fixture.componentRef.setInput('file', { fileName: 'nursery-batches.xlsx', bytes: await nurseryFile() });
    await vi.waitFor(() => {
      fixture.detectChanges();
      expect(fixture.nativeElement.querySelector('.steps')).toBeTruthy();
    });
    return fixture;
  }

  /** The three screens: 1 match the columns, 2 check the rows, 3 import. */
  function goTo(fixture: Awaited<ReturnType<typeof open>>, step: 1 | 2 | 3) {
    fixture.componentInstance.step.set(step);
    fixture.detectChanges();
  }

  it('starts on the matching, where the file\'s columns are laid out against the table\'s', async () => {
    const fixture = await open();
    const el: HTMLElement = fixture.nativeElement;
    expect(el.querySelector('.steps .is-on')?.textContent).toContain('Match columns');
    expect(el.querySelector('app-column-matcher')).toBeTruthy();
    expect(el.querySelector('.preview')).toBeNull();
    expect(el.textContent).not.toContain("can't be imported yet");
  });

  it('shows the rows, with the missing column empty and a warning, instead of stopping', async () => {
    const fixture = await open();
    goTo(fixture, 2);
    const el: HTMLElement = fixture.nativeElement;
    expect(el.querySelector('.alert-box.warning')?.textContent).toContain('“Variety name”');
    const heads = [...el.querySelectorAll('.preview th')].map((th) => th.textContent?.trim());
    expect(heads).toEqual(['Row', 'Supplier', 'Note', 'Variety name']);
    const rows = [...el.querySelectorAll('.preview tbody tr')];
    expect(rows.length).toBe(2);
    expect(rows[0].textContent).toContain('Kampot Seeds');
    // The missing column's cell is red on every row, and said once above rather than once per row.
    expect(el.querySelectorAll('.preview td.bad-cell').length).toBe(2);
    expect(el.querySelector('details.problems')).toBeNull();
  });

  it('brings the rows in only once the user ticks "with problems"', async () => {
    const fixture = await open();
    goTo(fixture, 3);
    const el: HTMLElement = fixture.nativeElement;
    const importButton = () => [...el.querySelectorAll('button.btn-primary')].find((b) => b.textContent?.includes('Import '))!;
    expect(importButton().textContent).toContain('Import 0 rows');
    const tick = el.querySelector<HTMLInputElement>('.final input.checkbox')!;
    tick.click();
    fixture.detectChanges();
    expect(importButton().textContent).toContain('Import 2 rows');
  });
});

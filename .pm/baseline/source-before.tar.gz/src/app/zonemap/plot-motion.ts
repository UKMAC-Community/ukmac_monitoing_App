/**
 * How the plots move on the satellite map (Zone Map): as the map opens a wave goes across the farm, each plot
 * rising out of the ground and standing up well over its height before it settles to it; they lift and light
 * up when pointed at, and lift smoothly when picked. Pure numbers: the map reads them as each plot's feature-state.
 */

/** The wait after the wave is asked for, before the first plot starts to rise. */
export const RISE_DELAY = 350;
/** How long one plot takes to rise, and how long the sweep takes to reach the last one (ms): slow enough to follow with the eye. */
export const RISE_MS = 650;
export const RISE_STAGGER = 1500;
/** When the opening is over (ms after it began). */
export const RISE_END = RISE_DELAY + RISE_STAGGER + RISE_MS;

/** How far over its height a plot stands at the top of its rise, in heights: a plot 3 m tall reaches about 24 m (from the far
 * side of the farm anything lower hardly shows). */
export const RISE_WAVE = 7;

/** How risen the `index`-th of `count` plots is, `t` ms after the opening began: from 0 up to a good deal over 1 and back to rest at 1. */
export function riseAt(t: number, index: number, count: number): number {
  const start = RISE_DELAY + (count > 1 ? (index / (count - 1)) * RISE_STAGGER : 0);
  const p = (t - start) / RISE_MS;
  if (p <= 0) return 0;
  if (p >= 1) return 1;
  return 1 - (1 - p) ** 3 + RISE_WAVE * Math.sin(Math.PI * p) ** 2;
}

/** `value` eased toward `target` over `dt` ms (exponentially, so it never jars when the target changes half way). */
export function approach(value: number, target: number, dt: number, tau = 90): number {
  return value + (target - value) * (1 - Math.exp(-dt / tau));
}

/** A colour (#rrggbb or #rgb) mixed with white by `amount`, 0 to 1; any other colour as it is. */
export function lighten(color: string, amount = 0.38): string {
  const match = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(color.trim());
  if (!match) return color;
  const hex = match[1].length === 3 ? [...match[1]].map((c) => c + c).join('') : match[1];
  const channels = [0, 2, 4].map((at) => {
    const value = parseInt(hex.slice(at, at + 2), 16);
    return Math.round(value + (255 - value) * amount);
  });
  return `#${channels.map((value) => value.toString(16).padStart(2, '0')).join('')}`;
}

/** The plots' ids from the west to the east, so the opening sweeps across the farm (those at the same place keep their order). */
export function sweepOrder(shapes: { id: string; points: [number, number][] }[]): string[] {
  const west = (shape: { points: [number, number][] }) => shape.points.reduce((sum, [, lng]) => sum + lng, 0) / (shape.points.length || 1);
  return shapes
    .map((shape, index) => ({ id: shape.id, at: west(shape), index }))
    .sort((a, b) => a.at - b.at || a.index - b.index)
    .map((item) => item.id);
}

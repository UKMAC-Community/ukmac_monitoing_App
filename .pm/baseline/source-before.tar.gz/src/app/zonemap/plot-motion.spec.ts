import { approach, lighten, riseAt, RISE_DELAY, RISE_END, RISE_MS, RISE_STAGGER, sweepOrder } from './plot-motion';

describe('how the plots move on the map', () => {
  it('has a plot start at the ground, and every one fully risen by the end of the opening', () => {
    for (const count of [1, 5, 105]) {
      for (let index = 0; index < count; index += 1) {
        expect(riseAt(0, index, count)).toBe(0);
        expect(riseAt(RISE_END, index, count)).toBeCloseTo(1, 6);
        expect(riseAt(RISE_END + 5000, index, count)).toBeCloseTo(1, 6);
      }
    }
  });

  it('sweeps: later plots start later, and none rises before the camera has begun to tip', () => {
    const t = RISE_DELAY + 200;
    expect(riseAt(t, 0, 10)).toBeGreaterThan(0);
    expect(riseAt(t, 9, 10)).toBe(0);
    expect(riseAt(RISE_DELAY - 1, 0, 10)).toBe(0);
    // The last one starts only when the stagger has run its course.
    expect(riseAt(RISE_DELAY + RISE_STAGGER - 1, 9, 10)).toBe(0);
    // The wave moves on: a plot that starts later is behind one that started earlier, in its own rise.
    const ahead = (index: number) => riseAt(RISE_DELAY + 200, index, 10) > 0;
    expect([0, 1, 2].map(ahead)).toEqual([true, true, false]);
  });

  it('stands up well over its height as the wave passes, then settles to it, never below the ground', () => {
    const values = Array.from({ length: 120 }, (_, k) => riseAt(RISE_DELAY + (k * RISE_MS) / 119, 0, 10));
    expect(Math.max(...values)).toBeGreaterThan(2.5); // a visible wave, not a shiver
    expect(values.at(-1)).toBe(1);
    expect(Math.min(...values)).toBeGreaterThanOrEqual(0);
    // It comes down after the top: the last stretch only goes down to rest.
    const peak = values.indexOf(Math.max(...values));
    for (let k = peak + 1; k < values.length; k += 1) expect(values[k]).toBeLessThanOrEqual(values[k - 1] + 1e-9);
  });

  it('eases toward a target without overshooting it, and a bigger wait gets closer', () => {
    let value = 0;
    for (let frame = 0; frame < 10; frame += 1) {
      const next = approach(value, 1, 16);
      expect(next).toBeGreaterThan(value);
      expect(next).toBeLessThan(1);
      value = next;
    }
    expect(approach(0, 1, 400)).toBeGreaterThan(approach(0, 1, 40));
    // A target that changes half way turns round smoothly.
    expect(approach(0.6, 0, 16)).toBeLessThan(0.6);
  });

  it('lightens a colour toward white, and leaves any it cannot read as it is', () => {
    expect(lighten('#000000', 0.5)).toBe('#808080');
    expect(lighten('#B9EFB9', 0)).toBe('#b9efb9');
    expect(lighten('#fff')).toBe('#ffffff');
    expect(lighten('#abc', 1)).toBe('#ffffff');
    expect(lighten('rgb(10, 20, 30)')).toBe('rgb(10, 20, 30)');
  });

  it('orders the plots from the west to the east', () => {
    const plot = (id: string, lng: number): { id: string; points: [number, number][] } => ({ id, points: [[11.1, lng], [11.2, lng + 0.0002], [11.1, lng + 0.0002]] });
    expect(sweepOrder([plot('c', 104.3), plot('a', 104.1), plot('b', 104.2), plot('a2', 104.1)])).toEqual(['a', 'a2', 'b', 'c']);
    expect(sweepOrder([])).toEqual([]);
  });
});

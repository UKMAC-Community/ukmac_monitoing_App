import { ChangeDetectionStrategy, Component, computed, DestroyRef, effect, inject, input, signal } from '@angular/core';
import { DashboardStudio } from '../dashboard/dashboard-studio';
import { SheetDashboard } from '../dashboard/sheet-dashboard';
import { dashboardOf } from '../dashboard/dashboard-model';
import { Router, RouterLink } from '@angular/router';

import { ColumnDialog } from '../components/column-dialog';
import { ColumnsPanel } from '../components/columns-panel';
import { Icon } from '../components/icon';
import { GoogleImportDialog } from '../components/google-import-dialog';
import { ImportDialog, type ImportDone, type ImportFile } from '../components/import-dialog';
import { Modal } from '../components/modal';
import { SheetTable } from '../components/sheet-table';
import { TableDialog } from '../components/table-dialog';
import { Api, errorText } from '../core/api';
import { Google } from '../core/google';
import type { Column, ImportRecord, Row, SheetWithRows } from '../core/models';
import { Shell } from '../core/shell';
import { Toasts } from '../core/toast';
import { WorkbookStore } from '../core/workbook-store';
import { buildTemplate } from '../excel/excel-template';
import { safeFileName } from '../excel/exceljs';
import { buildPowerBiWorkbook } from '../excel/powerbi-export';
import { formatFormulaValue, isFormulaError } from '../formula/evaluate-formula';
import { columnLabel, displayCell } from '../sheet/columns';
import { UniverSheet, type ColumnRequest } from '../univer/univer-sheet';

/** One table: the sheet, and everything done to it. */
@Component({
  selector: 'app-sheet-page',
  imports: [RouterLink, Icon, UniverSheet, SheetTable, SheetDashboard, DashboardStudio, ColumnDialog, ColumnsPanel, ImportDialog, GoogleImportDialog, TableDialog, Modal],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './sheet-page.html',
  styleUrl: './sheet-page.css',
})
export class SheetPage {
  readonly store = inject(WorkbookStore);
  readonly google = inject(Google);
  private readonly api = inject(Api);
  private readonly toasts = inject(Toasts);
  private readonly router = inject(Router);

  readonly sheetId = input.required<string>();
  /** `?view=dashboard`: the dashboard's editor; `?view=sheet`: the rows as a spreadsheet; else the table's page. */
  readonly view = input<string | undefined>();
  readonly mode = computed<'table' | 'dashboard' | 'sheet'>(() => (this.view() === 'dashboard' ? 'dashboard' : this.view() === 'sheet' ? 'sheet' : 'table'));
  readonly sheet = computed(() => this.store.sheet(Number(this.sheetId())));
  readonly linkOptions = (column: Column) => this.store.linkOptions(column);

  readonly search = signal('');
  readonly sort = signal<{ key: string; dir: 1 | -1 } | null>(null);

  // Dialogs.
  readonly columnDialog = signal<{ column: Column | null; insertAt: number; preset: Partial<Column> | null } | null>(null);
  readonly columnsOpen = signal(false);
  readonly settingsOpen = signal(false);
  readonly importFile = signal<ImportFile | null>(null);
  /** The Google Sheet picker, for this table. */
  readonly googleIntoOpen = signal(false);
  readonly importsOpen = signal(false);
  readonly imports = signal<ImportRecord[]>([]);
  readonly busy = signal(false);
  readonly newTableOpen = signal(false);
  readonly exportMenu = signal<{ x: number; y: number } | null>(null);
  /** The Import button's menu: an Excel file, or a Google Sheet. */
  readonly importMenu = signal<{ x: number; y: number } | null>(null);

  constructor() {
    // The sidebar stays open on the table's page; it folds only for the spreadsheet, as the system's sheet view does.
    const shell = inject(Shell);
    effect(() => (this.mode() === 'sheet' ? shell.enterSheet() : shell.leaveSheet()));
    inject(DestroyRef).onDestroy(() => shell.leaveSheet());
    void this.api
      .getSetting('sheet.kpiPanel')
      .then((value) => this.panelHidden.set(value === 'hidden'))
      .catch(() => undefined);
  }

  /** The KPI panel over the rows folded away (kept for next time, for every table). */
  readonly panelHidden = signal(false);
  readonly hasSummaries = computed(() => {
    const sheet = this.sheet();
    return !!sheet && dashboardOf(sheet).dashboard.summaries.length > 0;
  });

  togglePanel() {
    this.panelHidden.update((hidden) => !hidden);
    void this.api.setSetting('sheet.kpiPanel', this.panelHidden() ? 'hidden' : 'shown').catch(() => undefined);
  }

  setMode(mode: 'table' | 'dashboard' | 'sheet') {
    void this.router.navigate([], { queryParams: { view: mode === 'table' ? null : mode }, queryParamsHandling: 'merge', replaceUrl: true });
  }

  /** A column's header clicked in the table: A → Z, Z → A, then off. */
  sortBy(key: string) {
    const sort = this.sort();
    this.sort.set(!sort || sort.key !== key ? { key, dir: 1 } : sort.dir === 1 ? { key, dir: -1 } : null);
  }

  toggleImport(event: MouseEvent) {
    if (this.importMenu()) return this.importMenu.set(null);
    const box = (event.currentTarget as HTMLElement).getBoundingClientRect();
    this.importMenu.set({ x: Math.min(box.right - 260, window.innerWidth - 280), y: box.bottom + 6 });
  }

  toggleExport(event: MouseEvent) {
    if (this.exportMenu()) return this.exportMenu.set(null);
    const box = (event.currentTarget as HTMLElement).getBoundingClientRect();
    this.exportMenu.set({ x: Math.min(box.right - 260, window.innerWidth - 280), y: box.bottom + 6 });
  }

  tableCreated(sheet: SheetWithRows) {
    this.newTableOpen.set(false);
    void this.router.navigate(['/mac', sheet.macId, 'table', sheet.sheetId]);
  }

  readonly sortColumn = computed(() => {
    const sort = this.sort();
    return sort ? (this.sheet()?.columns.find((column) => column.key === sort.key) ?? null) : null;
  });

  /** The rows shown: those the search finds, in the chosen order. */
  readonly rows = computed<Row[]>(() => {
    const sheet = this.sheet();
    if (!sheet) return [];
    let rows = sheet.rows;
    const words = this.search().trim().toLowerCase().split(/\s+/).filter(Boolean);
    if (words.length) {
      rows = rows.filter((row) => {
        const text = sheet.columns.map((column) => this.cellText(sheet, row, column)).join(' ').toLowerCase();
        return words.every((word) => text.includes(word));
      });
    }
    const sort = this.sort();
    const column = this.sortColumn();
    if (sort && column) {
      const value = (row: Row) => {
        const raw = this.store.formulas().cell(sheet, row, column);
        if (raw === null || raw === '' || isFormulaError(raw)) return null;
        return raw;
      };
      rows = [...rows].sort((a, b) => {
        const x = value(a);
        const y = value(b);
        if (x === null && y === null) return 0;
        if (x === null) return 1;
        if (y === null) return -1;
        if (typeof x === 'number' && typeof y === 'number') return (x - y) * sort.dir;
        return String(x).localeCompare(String(y), 'en', { numeric: true, sensitivity: 'base' }) * sort.dir;
      });
    }
    return rows;
  });

  readonly filtered = computed(() => !!this.search().trim());
  readonly formulaCount = computed(() => this.sheet()?.columns.filter((column) => column.type === 'formula').length ?? 0);
  readonly problemCount = computed(() => {
    const sheet = this.sheet();
    if (!sheet) return 0;
    const formulas = this.store.formulas();
    const options = new Map(sheet.columns.filter((c) => c.type === 'link').map((c) => [c.key, this.store.linkOptions(c)]));
    let count = 0;
    for (const row of sheet.rows) for (const column of sheet.columns) if (formulas.problem(sheet, row, column, options.get(column.key))) count += 1;
    return count;
  });

  private cellText(sheet: SheetWithRows, row: Row, column: Column) {
    if (column.type === 'formula') {
      const value = this.store.formulas().value(sheet, row, column);
      return isFormulaError(value) ? '' : formatFormulaValue(value);
    }
    return displayCell(column, row.data[column.key]);
  }

  label(column: Column) {
    return columnLabel(column);
  }

  // ------------------------------------------------------------- columns

  openNewColumn(insertAt?: number, neighbour?: Column) {
    const sheet = this.sheet();
    if (!sheet) return;
    this.columnDialog.set({
      column: null,
      insertAt: insertAt ?? sheet.columns.length,
      preset: neighbour ? { box: neighbour.box, group: neighbour.group } : null,
    });
  }

  async saveColumn(column: Column) {
    const sheet = this.sheet();
    const dialog = this.columnDialog();
    if (!sheet || !dialog) return;
    const columns = [...sheet.columns];
    if (dialog.column) {
      const at = columns.findIndex((item) => item.key === dialog.column!.key);
      columns[at] = column;
    } else {
      columns.splice(dialog.insertAt, 0, column);
    }
    if (await this.saveColumns(columns)) {
      this.columnDialog.set(null);
      this.toasts.show(dialog.column ? `${column.name} saved` : `${column.name} added`);
    }
  }

  private async saveColumns(columns: Column[]) {
    const sheet = this.sheet();
    if (!sheet) return false;
    try {
      await this.store.saveColumns(sheet.sheetId, columns);
      return true;
    } catch (error) {
      this.toasts.error(errorText(error));
      return false;
    }
  }

  /** The formula columns (here and in the other tables) that name this one. */
  private usedBy(column: Column): string[] {
    const sheet = this.sheet();
    if (!sheet) return [];
    const names = [`[${column.name}]`, `› ${column.name}]`];
    const here = sheet.columns
      .filter((other) => other.key !== column.key && other.formula && names.some((name) => other.formula!.includes(name)))
      .map((other) => other.name);
    const elsewhere = this.store
      .sheets()
      .filter((other) => other.sheetId !== sheet.sheetId)
      .flatMap((other) =>
        other.columns
          .filter((item) => `${item.formula ?? ''}${item.source ?? ''}`.includes(`${sheet.title}'[${column.name}]`))
          .map((item) => `${other.title} › ${item.name}`),
      );
    return [...here, ...elsewhere];
  }

  async deleteColumn(column: Column) {
    const sheet = this.sheet();
    if (!sheet) return;
    const filled = sheet.rows.filter((row) => row.data[column.key]).length;
    const used = this.usedBy(column);
    const text = [
      `Delete the column “${columnLabel(column)}”${filled ? ` and its ${filled} filled cells` : ''}?`,
      used.length ? `These use it and will show #NAME? or #REF!: ${used.join(', ')}.` : '',
    ]
      .filter(Boolean)
      .join('\n\n');
    if (!(await this.api.confirm(text, 'Delete column', 'Delete'))) return;
    if (await this.saveColumns(sheet.columns.filter((item) => item.key !== column.key))) {
      this.toasts.show(`${column.name} deleted`);
    }
  }

  /** Several columns deleted at once (picked together in the sheet): one question for them all. */
  async deleteColumns(columns: Column[]) {
    const sheet = this.sheet();
    if (!sheet || !columns.length) return;
    if (columns.length === 1) return this.deleteColumn(columns[0]);
    const keys = new Set(columns.map((column) => column.key));
    const filled = sheet.rows.reduce((count, row) => count + columns.filter((column) => row.data[column.key]).length, 0);
    const used = columns.flatMap((column) => this.usedBy(column)).filter((name) => !columns.some((column) => name.endsWith(column.name)));
    const text = [
      `Delete these ${columns.length} columns (${columns.map(columnLabel).join(', ')})${filled ? ` and their ${filled} filled cells` : ''}?`,
      used.length ? `These use them and will show #NAME? or #REF!: ${[...new Set(used)].join(', ')}.` : '',
    ]
      .filter(Boolean)
      .join('\n\n');
    if (!(await this.api.confirm(text, 'Delete columns', 'Delete'))) return;
    if (await this.saveColumns(sheet.columns.filter((item) => !keys.has(item.key)))) {
      this.toasts.show(`${columns.length} columns deleted`);
    }
  }

  /** The sheet's column menus and header cells: the column's own dialogs do the change. */
  columnRequest(request: ColumnRequest) {
    const sheet = this.sheet();
    if (!sheet) return;
    switch (request.action) {
      case 'edit': {
        const column = sheet.columns[request.index];
        if (column) this.columnDialog.set({ column, insertAt: request.index, preset: null });
        return;
      }
      case 'insert':
        return this.openNewColumn(request.index, request.beside === null ? undefined : sheet.columns[request.beside]);
      case 'delete':
        return void this.deleteColumns(request.indexes.map((index) => sheet.columns[index]).filter((column) => !!column));
      case 'move':
        return void this.reorderColumns(request.order.map((index) => sheet.columns[index]).filter((column) => !!column));
    }
  }

  async reorderColumns(columns: Column[]) {
    if (await this.saveColumns(columns)) {
      this.toasts.show('Column order saved');
      this.columnsOpen.set(false);
    }
  }

  // --------------------------------------------------------------- Excel

  async downloadTemplate() {
    const sheet = this.sheet();
    if (!sheet) return;
    const path = await this.api.pickSavePath(`${safeFileName(sheet.title)} template.xlsx`);
    if (!path) return;
    this.busy.set(true);
    try {
      const bytes = await buildTemplate(sheet, { linkOptions: this.linkOptions });
      await this.api.writeFile(path, bytes);
      this.toasts.show(`Template saved: ${path.split('/').pop()}`);
    } catch (error) {
      this.toasts.error(errorText(error));
    } finally {
      this.busy.set(false);
    }
  }

  /** A tab picked from a Google Sheet: it goes to the same preview as an Excel file. */
  googlePicked(file: ImportFile) {
    this.googleIntoOpen.set(false);
    this.importFile.set(file);
  }

  async pickImport() {
    const path = await this.api.pickExcelFile();
    if (!path) return;
    try {
      const bytes = await this.api.readFile(path);
      this.importFile.set({ fileName: path.split('/').pop() ?? path, bytes });
    } catch (error) {
      this.toasts.error(errorText(error));
    }
  }

  imported({ count, headerMap }: ImportDone) {
    const connect = this.importFile()?.connect;
    const sheet = this.sheet();
    this.importFile.set(null);
    this.search.set('');
    this.toasts.show(`${count} row${count === 1 ? '' : 's'} imported and saved`, 'ok', {
      label: 'Undo',
      run: () => void this.undoLastImport(),
    });
    // Imported from a Google Sheet tab and asked to stay connected: the link keeps the column matches.
    if (connect && headerMap && sheet) {
      this.google
        .connectTable(sheet.sheetId, { spreadsheetId: connect.spreadsheetId, spreadsheetTitle: connect.spreadsheetTitle, tabTitle: connect.tabTitle, headerMap }, count)
        .then(() => this.toasts.show(`Connected to “${connect.spreadsheetTitle} › ${connect.tabTitle}”. Press Sync to read it again.`))
        .catch((error) => this.toasts.error(`The rows are in, but the table couldn't be connected to Google: ${errorText(error)}`));
    }
  }

  private async undoLastImport() {
    const sheet = this.sheet();
    if (!sheet) return;
    const [last] = await this.api.listImports(sheet.sheetId);
    if (last) await this.undoImport(last, false);
  }

  async openImports() {
    const sheet = this.sheet();
    if (!sheet) return;
    this.imports.set(await this.api.listImports(sheet.sheetId));
    this.importsOpen.set(true);
  }

  async undoImport(record: ImportRecord, ask = true) {
    const sheet = this.sheet();
    if (!sheet) return;
    if (ask && !(await this.api.confirm(`Take out the ${record.rowsLeft} rows ${record.fileName} brought in?`, 'Undo import', 'Take them out'))) return;
    try {
      const removed = await this.store.undoImport(sheet.sheetId, record.importId);
      this.toasts.show(`${removed} imported row${removed === 1 ? '' : 's'} taken out`);
      if (this.importsOpen()) this.imports.set(await this.api.listImports(sheet.sheetId));
    } catch (error) {
      this.toasts.error(errorText(error));
    }
  }

  async exportTable() {
    const sheet = this.sheet();
    const book = this.store.workbook();
    if (!sheet || !book) return;
    const path = await this.api.pickSavePath(`${safeFileName(sheet.title)} - ${safeFileName(book.mac.macCode)}.xlsx`);
    if (!path) return;
    try {
      await this.api.writeFile(path, await buildPowerBiWorkbook([{ mac: book.mac, sheets: [sheet] }], { single: true }));
      this.toasts.show(`Saved ${path.split('/').pop()}`);
    } catch (error) {
      this.toasts.error(errorText(error));
    }
  }

  // --------------------------------------------------------------- table

  async deleteTable(sheet: SheetWithRows) {
    const links = this.store
      .sheets()
      .filter((other) => other.sheetId !== sheet.sheetId)
      .filter((other) => other.columns.some((column) => `${column.source ?? ''}${column.formula ?? ''}`.includes(`'${sheet.title}'[`)))
      .map((other) => other.title);
    const text = [
      `Delete the table “${sheet.title}” and its ${sheet.rows.length} rows? This can't be undone.`,
      links.length ? `These tables pick values from it: ${links.join(', ')}.` : '',
    ]
      .filter(Boolean)
      .join('\n\n');
    if (!(await this.api.confirm(text, 'Delete table', 'Delete'))) return;
    try {
      await this.store.deleteSheet(sheet.sheetId);
      this.settingsOpen.set(false);
      this.toasts.show(`${sheet.title} deleted`);
      void this.router.navigate(['/mac', sheet.macId]);
    } catch (error) {
      this.toasts.error(errorText(error));
    }
  }

  when(at: string) {
    // SQLite keeps UTC: show it in Cambodia time.
    const date = new Date(`${at.replace(' ', 'T')}Z`);
    return Number.isNaN(date.getTime())
      ? at
      : date.toLocaleString('en-GB', { timeZone: 'Asia/Phnom_Penh', dateStyle: 'medium', timeStyle: 'short' });
  }
}

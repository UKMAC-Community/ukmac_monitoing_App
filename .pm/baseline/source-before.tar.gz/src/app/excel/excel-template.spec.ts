import type { Column } from '../core/models';
import { makeSheet, qaQcColumns } from '../test-helpers';
import { loadExcel } from './exceljs';
import { buildTemplate, readImport } from './excel-template';

const plots = ['A1', 'A2', 'B1'];
const ctx = { linkOptions: (column: Column) => (column.source?.includes('Zones') ? plots : []) };

async function fill(template: ArrayBuffer, rows: (string | number | Date | null)[][]) {
  const Excel = await loadExcel();
  const book = new Excel.Workbook();
  await book.xlsx.load(template);
  const data = book.getWorksheet('Data')!;
  rows.forEach((row, index) => {
    row.forEach((value, column) => {
      if (value !== null) data.getCell(index + 2, column + 1).value = value;
    });
  });
  return (await book.xlsx.writeBuffer()) as ArrayBuffer;
}

describe('Excel template and import', () => {
  const qc = makeSheet(2, 'QA/QC Management', qaQcColumns());

  it('writes the Data sheet with the server headers, no formula columns, and the Lists', async () => {
    const Excel = await loadExcel();
    const book = new Excel.Workbook();
    await book.xlsx.load(await buildTemplate(qc, ctx));
    const data = book.getWorksheet('Data')!;
    const headers: string[] = [];
    data.getRow(1).eachCell((cell) => headers.push(String(cell.value)));
    expect(headers).toEqual([
      'Date',
      'Zone',
      'QC record · Plant batch',
      '1 · Transplant (0 DAT) · Disease',
      '2 · Establishment (7 DAT) · Live plant',
    ]);
    expect(book.getWorksheet('Lists')!.getCell('A2').value).toBe('A1');
    expect(book.getWorksheet('Instructions')).toBeTruthy();
  });

  it('reads the filled template back, checking each value', async () => {
    const filled = await fill(await buildTemplate(qc, ctx), [
      ['16/06/2026', 'a1', 'B-01', 2, 19],
      [new Date(Date.UTC(2026, 5, 17)), 'Z9', null, 'none', 20],
      [null, null, null, null, null],
      ['2026-06-18', 'B1', null, null, '18'],
    ]);
    const preview = await readImport(filled, 'qc.xlsx', qc, ctx);
    expect(preview.issues).toEqual([]);
    expect(preview.rows.length).toBe(3); // the blank row is skipped
    expect(preview.rows[0].cells).toEqual({ c1: '2026-06-16', c2: 'A1', c3: 'B-01', c6: '2', c9: '19' });
    expect(preview.rows[0].errors).toEqual([]);
    expect(preview.rows[1].cells['c1']).toBe('2026-06-17');
    expect(preview.rows[1].errors.map((error) => error.key).sort()).toEqual(['c2', 'c6']);
    expect(preview.errorRows).toBe(1);
    expect(preview.missingLinks).toEqual([expect.objectContaining({ values: ['Z9'] })]);
    expect(preview.rows[2].cells['c9']).toBe('18');
  });

  it("takes a farm's own sheet: another name, a title row above, extra columns, box paths", async () => {
    const Excel = await loadExcel();
    const book = new Excel.Workbook();
    const sheet = book.addWorksheet('June checks');
    sheet.addRow(['QC June 2026']);
    sheet.addRow(['Zone', 'Date', 'Checked by', '2 · Establishment (7 DAT) › Plant Survival (No.) › Live plant', 'Dead plant']);
    sheet.addRow(['A2', '01/06/2026', 'Sokha', 17, 3]);
    const preview = await readImport((await book.xlsx.writeBuffer()) as ArrayBuffer, 'june.xlsx', qc, ctx);
    expect(preview.headerRow).toBe(2);
    expect(preview.unknownHeaders).toEqual(['Checked by']);
    expect(preview.workedOut).toEqual(['Dead plant']);
    expect(preview.rows[0].cells).toEqual({ c2: 'A2', c1: '2026-06-01', c9: '17' });
  });

  it('still reads the rows when a required column is missing, marking each', async () => {
    const Excel = await loadExcel();
    const book = new Excel.Workbook();
    book.addWorksheet('Data').addRow(['Zone']).commit();
    book.getWorksheet('Data')!.addRow(['A1']);
    const preview = await readImport((await book.xlsx.writeBuffer()) as ArrayBuffer, 'x.xlsx', qc, ctx);
    expect(preview.issues).toEqual([]);
    expect(preview.missingRequired).toEqual([{ key: 'c1', header: 'Date' }]);
    expect(preview.rows.length).toBe(1);
    expect(preview.rows[0].cells).toEqual({ c2: 'A1' });
    expect(preview.rows[0].errors.map((error) => error.key)).toEqual(['c1']);
    expect(preview.errorRows).toBe(1);
  });

  it('reads the tab it is told to, not the first one', async () => {
    const Excel = await loadExcel();
    const book = new Excel.Workbook();
    book.addWorksheet('Summary').addRow(['Notes']);
    const tab = book.addWorksheet('June checks');
    tab.addRow(['Zone', 'Date']);
    tab.addRow(['A2', '01/06/2026']);
    const bytes = (await book.xlsx.writeBuffer()) as ArrayBuffer;
    const preview = await readImport(bytes, 'g.xlsx', qc, ctx, { tab: 'June checks' });
    expect(preview.sheetName).toBe('June checks');
    expect(preview.issues).toEqual([]);
    expect(preview.rows[0].cells).toEqual({ c2: 'A2', c1: '2026-06-01' });
    await expect(readImport(bytes, 'g.xlsx', qc, ctx, { tab: 'Missing' })).rejects.toThrow('isn\'t in the workbook');
  });

  it("fills the columns the user matched, whatever the file calls them, and leaves the rest out", async () => {
    const Excel = await loadExcel();
    const book = new Excel.Workbook();
    const tab = book.addWorksheet('Visits');
    tab.addRow(['Title of the report']);
    tab.addRow(['Where', '', 'When', 'Zone', 'Notes']); // an empty header cell: positions skip it
    tab.addRow(['B1', '', '02/06/2026', 'ignored', 'x']);
    const bytes = (await book.xlsx.writeBuffer()) as ArrayBuffer;
    // Date (c1) ← "When" (column 3); Zone (c2) ← "Where" (column 1). The file's own "Zone" column is not used.
    const preview = await readImport(bytes, 'v.xlsx', qc, ctx, { columns: { c1: 3, c2: 1 }, headerRow: 2 });
    expect(preview.headerRow).toBe(2);
    expect(preview.issues).toEqual([]);
    expect(preview.matched.map((item) => [item.key, item.fileHeader])).toEqual([
      ['c2', 'Where'],
      ['c1', 'When'],
    ]);
    expect(preview.unknownHeaders).toEqual(['Zone', 'Notes']);
    expect(preview.rows[0].cells).toEqual({ c2: 'B1', c1: '2026-06-02' });
  });

  it('reports every column of the file, with a sample, whether or not it matched; a "*" on a header is no part of its name', async () => {
    const Excel = await loadExcel();
    const book = new Excel.Workbook();
    const sheet = book.addWorksheet('Data');
    sheet.addRow(['Zone *', 'Remarks', 'Date']);
    sheet.addRow(['A1', 'dry', '01/06/2026']);
    const bytes = (await book.xlsx.writeBuffer()) as ArrayBuffer;
    const preview = await readImport(bytes, 'f.xlsx', qc, ctx);
    expect(preview.fileColumns).toEqual([
      { position: 1, header: 'Zone *', sample: 'A1' },
      { position: 2, header: 'Remarks', sample: 'dry' },
      { position: 3, header: 'Date', sample: '01/06/2026' },
    ]);
    expect(preview.matched.map((item) => [item.key, item.position])).toEqual([
      ['c2', 1],
      ['c1', 3],
    ]);
    expect(preview.unknownHeaders).toEqual(['Remarks']);
  });

  it('still lists the file\'s columns when none of them match, so they can be matched by hand', async () => {
    const Excel = await loadExcel();
    const book = new Excel.Workbook();
    const sheet = book.addWorksheet('Data');
    sheet.addRow(['Place', 'Day']);
    sheet.addRow(['A1', '01/06/2026']);
    const bytes = (await book.xlsx.writeBuffer()) as ArrayBuffer;
    const preview = await readImport(bytes, 'f.xlsx', qc, ctx);
    expect(preview.issues[0]).toContain('Match the columns by hand');
    expect(preview.fileColumns.map((column) => column.header)).toEqual(['Place', 'Day']);
    // Matched by hand, they fill the table.
    const mapped = await readImport(bytes, 'f.xlsx', qc, ctx, { columns: { c2: 1, c1: 2 }, headerRow: 1 });
    expect(mapped.issues).toEqual([]);
    expect(mapped.rows[0].cells).toEqual({ c2: 'A1', c1: '2026-06-01' });
  });

  it('with no matching names, takes the first row with two or more cells as the headers, not a title above it', async () => {
    const Excel = await loadExcel();
    const book = new Excel.Workbook();
    const sheet = book.addWorksheet('Data');
    sheet.addRow(['Report of June']);
    sheet.addRow(['Place', 'Day']);
    sheet.addRow(['A1', '01/06/2026']);
    const preview = await readImport((await book.xlsx.writeBuffer()) as ArrayBuffer, 'f.xlsx', qc, ctx);
    expect(preview.headerRow).toBe(2);
    expect(preview.fileColumns.map((column) => column.header)).toEqual(['Place', 'Day']);
  });

  it('only takes .xlsx files', async () => {
    await expect(readImport(new ArrayBuffer(4), 'old.xls', qc, ctx)).rejects.toThrow('.xlsx');
  });
});

import type { Cells, Column, Sheet } from '../core/models';
import {
  checkCell,
  columnLabel,
  excelHeaders,
  excelSerialToIso,
  headerAliases,
  isEntryColumn,
  normalizeHeader,
  parseLinkSource,
  typeLabel,
} from '../sheet/columns';
import { loadExcel, styleHeader, type ExcelJS } from './exceljs';

/**
 * A table's Excel template and import — the server's way: a "Data" sheet
 * whose first row is the table's columns (as `excelHeaders` names them),
 * filled in and imported back; a column is matched by its header.
 *
 * Kinder than the server on a farm's own workbook: a sheet that isn't
 * called "Data" is read too (the first one), a header row lower down is
 * found, Excel's own dates and formulas' results are taken, and a column
 * the table doesn't have is left out with a note instead of stopping it.
 */

export const MAX_IMPORT_ROWS = 5000;
export const MAX_FILE_BYTES = 15 * 1024 * 1024;
/** Rows of the template given drop-down lists. */
const TEMPLATE_ROWS = 500;

export interface TemplateContext {
  /** A link column's values to pick from. */
  linkOptions: (column: Column) => string[];
}

function describe(column: Column, ctx: TemplateContext): string {
  const parts = [column.required ? 'Required.' : 'Optional.', `${typeLabel(column.type)}.`];
  switch (column.type) {
    case 'number':
      parts.push('Enter a number.');
      break;
    case 'percentage':
      parts.push('Enter a number out of 100 (the % sign is optional).');
      break;
    case 'date':
      parts.push('Use a date like 16/06/2026 or 2026-06-16, or an Excel date.');
      break;
    case 'yesno':
      parts.push('Yes or No.');
      break;
    case 'choice':
      parts.push(`One of: ${(column.options ?? []).join(', ')}.`);
      break;
    case 'link': {
      const source = parseLinkSource(column.source);
      const count = ctx.linkOptions(column).length;
      parts.push(
        source
          ? `A ${source.column} from the ${source.table} table (${count} to pick from, see the Lists sheet).`
          : 'A value from the linked table.',
      );
      break;
    }
  }
  if (column.note) parts.push(column.note);
  return parts.join(' ');
}

function listValues(column: Column, ctx: TemplateContext): string[] {
  if (column.type === 'choice') return column.options ?? [];
  if (column.type === 'yesno') return ['Yes', 'No'];
  if (column.type === 'link') return ctx.linkOptions(column);
  return [];
}

function columnLetter(index: number) {
  let n = index;
  let letters = '';
  while (n > 0) {
    const rest = (n - 1) % 26;
    letters = String.fromCharCode(65 + rest) + letters;
    n = Math.floor((n - 1) / 26);
  }
  return letters;
}

/** The table's blank Excel template (.xlsx bytes). */
export async function buildTemplate(sheet: Sheet, ctx: TemplateContext): Promise<ArrayBuffer> {
  const Excel = await loadExcel();
  const book = new Excel.Workbook();
  book.creator = 'UKMAC Monitoring';
  book.title = sheet.title;
  const headers = excelHeaders(sheet.columns);
  const columns = sheet.columns.filter(isEntryColumn);

  const data = book.addWorksheet('Data');
  data.columns = columns.map((column) => ({
    header: headers.get(column.key)!,
    key: column.key,
    width: Math.min(40, Math.max(14, headers.get(column.key)!.length + 2)),
  }));
  styleHeader(data);

  // Drop-down lists, from the Lists sheet.
  const lists = book.addWorksheet('Lists');
  let listColumn = 0;
  columns.forEach((column, index) => {
    const header = data.getCell(1, index + 1);
    header.note = describe(column, ctx);
    const excelColumn = data.getColumn(index + 1);
    if (column.type === 'date' || column.type === 'text' || column.type === 'link' || column.type === 'choice') {
      // Text, so Excel keeps a date or a code as it's typed.
      excelColumn.numFmt = '@';
    }
    const values = listValues(column, ctx);
    if (!values.length) return;
    listColumn += 1;
    const letter = columnLetter(listColumn);
    lists.getCell(1, listColumn).value = headers.get(column.key)!;
    values.forEach((value, at) => (lists.getCell(at + 2, listColumn).value = value));
    lists.getColumn(listColumn).width = Math.min(40, Math.max(14, headers.get(column.key)!.length + 2));
    const range = `Lists!$${letter}$2:$${letter}$${values.length + 1}`;
    for (let row = 2; row <= TEMPLATE_ROWS + 1; row += 1) {
      data.getCell(row, index + 1).dataValidation = {
        type: 'list',
        allowBlank: true,
        formulae: [range],
        showErrorMessage: column.type !== 'link',
        errorStyle: 'warning',
        errorTitle: 'Not in the list',
        error: 'Pick a value from the list.',
      };
    }
  });
  if (listColumn) styleHeader(lists);

  const instructions = book.addWorksheet('Instructions');
  instructions.columns = [
    { header: 'Column', width: 42 },
    { header: 'How to fill it in', width: 110 },
  ];
  instructions.addRow([
    sheet.title,
    `Enter one record per row on the Data sheet (up to ${MAX_IMPORT_ROWS}). Keep the headers in row 1. Blank rows are skipped.`,
  ]);
  instructions.addRow([
    'Importing',
    'In UKMAC Monitoring, open the table and choose Import Excel. You see every row before anything is saved, and you can undo an import.',
  ]);
  for (const column of columns) instructions.addRow([headers.get(column.key)!, describe(column, ctx)]);
  const worked = sheet.columns.filter((column) => column.type === 'formula');
  if (worked.length) {
    instructions.addRow([
      'Worked out by the app',
      `Not in the template, the app works them out: ${worked.map((column) => columnLabel(column)).join(', ')}.`,
    ]);
  }
  styleHeader(instructions);
  instructions.getColumn(2).alignment = { wrapText: true, vertical: 'top' };

  return book.xlsx.writeBuffer() as Promise<ArrayBuffer>;
}

// ---------------------------------------------------------------- import

export interface ImportCellError {
  key: string;
  header: string;
  message: string;
}

export interface ImportRow {
  rowNumber: number;
  cells: Cells;
  errors: ImportCellError[];
}

export interface FileColumn {
  /** The worksheet column, 1-based. */
  position: number;
  header: string;
  /** The first value under it. */
  sample: string;
}

export interface ImportPreview {
  fileName: string;
  sheetName: string;
  headerRow: number;
  /** The table's columns found in the file, in the file's order. */
  matched: { key: string; header: string; fileHeader: string; /** The worksheet column (1-based) that fills it. */ position: number }[];
  /** Every column of the file's header row, with the first value under it: what can be matched. */
  fileColumns: FileColumn[];
  /** Headers in the file the table hasn't: left out. */
  unknownHeaders: string[];
  /** The table's columns the file hasn't: left blank. */
  missing: Column[];
  /** Of those, the ones every row needs: the rows are still read and shown, each marked for it. */
  missingRequired: { key: string; header: string }[];
  /** Formula columns the file has: worked out by the app instead. */
  workedOut: string[];
  rows: ImportRow[];
  /** Problems with the whole file. */
  issues: string[];
  /** A link column's values not in its table yet, by column key. */
  missingLinks: { column: Column; header: string; values: string[] }[];
  errorRows: number;
}

class ImportError extends Error {}

function textOf(value: ExcelJS.CellValue, column: Column | undefined, date1904: boolean): string {
  if (value === null || value === undefined) return '';
  if (typeof value === 'string') return value.trim();
  if (typeof value === 'number') {
    if (column?.type === 'date') return excelSerialToIso(value, date1904) ?? String(value);
    return String(Number(value.toPrecision(15)));
  }
  if (typeof value === 'boolean') return value ? 'Yes' : 'No';
  if (value instanceof Date) {
    if (!Number.isFinite(value.getTime())) return '';
    // exceljs gives an Excel date as that day's midnight, UTC.
    return value.toISOString().slice(0, 10);
  }
  if (typeof value === 'object') {
    if ('richText' in value) return value.richText.map((part) => part.text).join('').trim();
    if ('error' in value) throw new ImportError(`Excel shows ${value.error} here`);
    if ('result' in value) {
      const result = (value as { result?: ExcelJS.CellValue }).result;
      return result === undefined ? '' : textOf(result as ExcelJS.CellValue, column, date1904);
    }
    if ('text' in value) return String((value as { text: unknown }).text ?? '').trim();
  }
  return String(value).trim();
}

/** Reads an .xlsx file's rows into the table's columns, checking each value. Nothing is saved. */
export async function readImport(
  bytes: ArrayBuffer,
  fileName: string,
  sheet: Sheet,
  ctx: TemplateContext,
  options: {
    /** The tab to read (a Google Sheet's tab the user picked); else "Data", else the first with rows. */
    tab?: string;
    /** The user's own matches: table column key → the worksheet column (1-based) that fills it. The
     * file's names aren't used then; a column not matched here is left out, whatever it's called. */
    columns?: Record<string, number>;
    /** The row the headers are on, when the matches were made against it. */
    headerRow?: number;
  } = {},
): Promise<ImportPreview> {
  if (!/\.xlsx$/i.test(fileName)) throw new Error('Choose an .xlsx workbook. Save an older .xls file as .xlsx first.');
  if (bytes.byteLength > MAX_FILE_BYTES) throw new Error('Keep the workbook under 15 MB.');
  const Excel = await loadExcel();
  const book = new Excel.Workbook();
  try {
    await book.xlsx.load(bytes);
  } catch {
    throw new Error("This workbook can't be read. Use an .xlsx file that isn't password-protected.");
  }
  const date1904 = Boolean((book.properties as { date1904?: boolean }).date1904);
  const worksheet = options.tab
    ? book.worksheets.find((ws) => ws.name === options.tab)
    : (book.worksheets.find((ws) => ws.name.trim().toLowerCase() === 'data') ??
      book.worksheets.find((ws) => ws.state !== 'hidden' && ws.actualRowCount > 0));
  if (!worksheet) throw new Error(options.tab ? `The tab “${options.tab}” isn't in the workbook.` : 'The workbook has no sheet with data.');

  const headers = excelHeaders(sheet.columns);
  const entry = sheet.columns.filter(isEntryColumn);
  // Each name a column answers to → its column (names two columns share don't count).
  const byAlias = new Map<string, Column | null>();
  for (const column of entry) {
    for (const alias of headerAliases(column, headers.get(column.key)!)) {
      byAlias.set(alias, byAlias.has(alias) && byAlias.get(alias)?.key !== column.key ? null : column);
    }
  }
  // A column's own template header is always its (they're never shared).
  for (const column of entry) byAlias.set(normalizeHeader(headers.get(column.key)!), column);
  const formulaNames = new Set(
    sheet.columns
      .filter((column) => column.type === 'formula')
      .flatMap((column) => [column.name, columnLabel(column), column.box ? `${column.box} · ${columnLabel(column)}` : ''])
      .filter(Boolean)
      .map(normalizeHeader),
  );

  // The header row: the one the user's matches were made on, else of the first 10 the one naming the most columns.
  let headerRow = options.headerRow ?? 1;
  if (!options.headerRow) {
    let best = -1;
    let firstWide = 0;
    for (let at = 1; at <= Math.min(10, worksheet.rowCount); at += 1) {
      let found = 0;
      let filled = 0;
      worksheet.getRow(at).eachCell((cell) => {
        filled += 1;
        try {
          if (byAlias.get(normalizeHeader(textOf(cell.value, undefined, date1904)))) found += 1;
        } catch {
          /* an error cell isn't a header */
        }
      });
      if (filled >= 2 && !firstWide) firstWide = at;
      if (found > best) {
        best = found;
        headerRow = at;
      }
    }
    // No row names any column (the user matches them by hand): the first with two or more filled cells, as a new table's reader takes.
    if (best <= 0 && firstWide) headerRow = firstWide;
  }

  const issues: string[] = [];
  const matched: ImportPreview['matched'] = [];
  const unknownHeaders: string[] = [];
  const workedOut: string[] = [];
  const columnAt = new Map<number, Column>();
  const fileColumns: FileColumn[] = [];
  worksheet.getRow(headerRow).eachCell((cell, at) => {
    let text = '';
    try {
      text = textOf(cell.value, undefined, date1904);
    } catch {
      issues.push(`Header in column ${at}: use plain text.`);
      return;
    }
    if (!text) return;
    fileColumns.push({ position: at, header: text, sample: '' });
    const normalized = normalizeHeader(text);
    if (options.columns) {
      const key = Object.keys(options.columns).find((item) => options.columns![item] === at);
      const mine = key ? entry.find((item) => item.key === key) : undefined;
      if (mine) {
        columnAt.set(at, mine);
        matched.push({ key: mine.key, header: headers.get(mine.key)!, fileHeader: text, position: at });
      } else {
        unknownHeaders.push(text);
      }
      return;
    }
    const column = byAlias.get(normalized);
    if (column) {
      if ([...columnAt.values()].some((other) => other.key === column.key)) {
        issues.push(`Two columns in the file are both “${headers.get(column.key)}”. Keep one.`);
        return;
      }
      columnAt.set(at, column);
      matched.push({ key: column.key, header: headers.get(column.key)!, fileHeader: text, position: at });
    } else if (formulaNames.has(normalized)) {
      workedOut.push(text);
    } else {
      unknownHeaders.push(text);
    }
  });
  // What each column of the file holds, as the first value under it (for the user to match by).
  for (const column of fileColumns) {
    for (let at = headerRow + 1; at <= Math.min(worksheet.rowCount, headerRow + 40) && !column.sample; at += 1) {
      try {
        column.sample = textOf(worksheet.getRow(at).getCell(column.position).value, undefined, date1904);
      } catch {
        /* an error cell holds nothing to show */
      }
    }
  }
  if (!matched.length) {
    issues.push(
      options.columns
        ? 'Match at least one column of the file to a column of the table.'
        : `No column of ${sheet.title} was found in “${worksheet.name}”. Match the columns by hand above, or download the table's Excel template and use its headers.`,
    );
  }
  const missing = entry.filter((column) => !matched.some((item) => item.key === column.key));
  // A required column the file hasn't doesn't stop the import: the rows are still read and shown,
  // each marked as needing it, and the user chooses whether to bring them in.
  const missingRequired = missing.filter((item) => item.required).map((column) => ({ key: column.key, header: headers.get(column.key)! }));

  const linkOptions = new Map<string, string[]>();
  for (const column of entry.filter((item) => item.type === 'link')) linkOptions.set(column.key, ctx.linkOptions(column));
  const missingLinks = new Map<string, Set<string>>();

  const rows: ImportRow[] = [];
  if (!issues.length) {
    for (let at = headerRow + 1; at <= worksheet.rowCount; at += 1) {
      const excelRow = worksheet.getRow(at);
      if (!excelRow.hasValues) continue;
      const cells: Cells = {};
      const errors: ImportCellError[] = [];
      let filled = false;
      for (const [index, column] of columnAt) {
        const header = headers.get(column.key)!;
        let text = '';
        try {
          text = textOf(excelRow.getCell(index).value, column, date1904);
        } catch (error) {
          errors.push({ key: column.key, header, message: (error as Error).message });
          continue;
        }
        if (!text) continue;
        filled = true;
        const checked = checkCell(column, text, linkOptions.get(column.key));
        cells[column.key] = checked.value;
        if (checked.error) {
          errors.push({ key: column.key, header, message: checked.error });
          if (column.type === 'link') {
            const set = missingLinks.get(column.key) ?? new Set<string>();
            set.add(checked.value);
            missingLinks.set(column.key, set);
          }
        }
      }
      if (!filled) continue;
      for (const column of entry) {
        if (column.required && !cells[column.key] && !errors.some((error) => error.key === column.key)) {
          errors.push({ key: column.key, header: headers.get(column.key)!, message: 'This column needs a value' });
        }
      }
      rows.push({ rowNumber: at, cells, errors });
      if (rows.length > MAX_IMPORT_ROWS) {
        issues.push(`Import at most ${MAX_IMPORT_ROWS} rows at a time. Split the file and import each part.`);
        break;
      }
    }
    if (!rows.length && !issues.length) {
      issues.push(`“${worksheet.name}” has no rows under its headers. Fill in at least one row.`);
    }
  }

  return {
    fileName,
    sheetName: worksheet.name,
    headerRow,
    matched,
    fileColumns,
    unknownHeaders,
    missing,
    missingRequired,
    workedOut,
    rows,
    issues,
    missingLinks: [...missingLinks.entries()].map(([key, values]) => {
      const column = entry.find((item) => item.key === key)!;
      return { column, header: headers.get(key)!, values: [...values] };
    }),
    errorRows: rows.filter((row) => row.errors.length).length,
  };
}

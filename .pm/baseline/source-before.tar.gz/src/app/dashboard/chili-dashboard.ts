import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';

import type { Column, KpiAggregate, SheetWithRows } from '../core/models';
import type { WorkbookFormulas } from '../formula/sheet-formulas';
import { isIsoDate } from '../sheet/columns';
import { columnValues, formatNumber, reduceValues, type ChartPoint } from './dashboard-model';
import { KpiChart } from './kpi-chart';

/**
 * A chili MAC's dashboard, as the system's Chili page draws its starter
 * report (`cropDashboardReport`): Power BI KPI tiles, each its latest
 * year's value next to the year before, over its trend year to year —
 * Nursery, Planting, then QC — and the seedlings and plants planted by
 * year. Read from the MAC's chili tables (found by their template keys,
 * their columns by name); one whose table or column isn't there is left out.
 */

interface YearKpiSpec {
  title: string;
  table: string;
  column: string | null;
  box?: string;
  aggregate: KpiAggregate;
  year: string;
  /** The year column's box: '' none (the row's own Date). */
  yearBox?: string;
  decimals?: number;
}

const NURSERY = 'nursery-batches';
const RECORDS = 'zone-records';
const QC = 'qa-qc-management';

const KPIS: YearKpiSpec[] = [
  { title: 'Seedlings', table: NURSERY, column: 'Total number', aggregate: 'sum', year: 'Supply date' },
  { title: 'Healthy %', table: NURSERY, column: 'Healthy %', aggregate: 'average', year: 'Supply date', decimals: 1 },
  { title: 'Batches', table: NURSERY, column: null, aggregate: 'count', year: 'Supply date' },
  { title: 'Healthy seedlings', table: NURSERY, column: 'Healthy', aggregate: 'sum', year: 'Supply date' },
  { title: 'Not healthy', table: NURSERY, column: 'Not healthy', aggregate: 'sum', year: 'Supply date' },
  { title: 'Stem rot', table: NURSERY, column: 'Stem rot', aggregate: 'sum', year: 'Supply date' },
  { title: 'Average height (cm)', table: NURSERY, column: 'Mean height (cm)', aggregate: 'average', year: 'Supply date', decimals: 1 },
  { title: 'Plants planted', table: RECORDS, column: 'Plant count', aggregate: 'sum', year: 'Record date' },
  { title: 'Dead after planting', table: RECORDS, column: 'Dead plant', aggregate: 'sum', year: 'Record date' },
  { title: 'Harvest (kg)', table: QC, column: 'Harvested', box: '8 ·', aggregate: 'sum', year: 'Date', yearBox: '', decimals: 1 },
  { title: 'QC records', table: QC, column: null, aggregate: 'count', year: 'Date', yearBox: '' },
  { title: 'Live plants (avg of 20)', table: QC, column: 'Live plant', box: '2 ·', aggregate: 'average', year: 'Date', yearBox: '', decimals: 1 },
  { title: 'Marketable fruit (kg)', table: QC, column: 'Marketable', box: '8 ·', aggregate: 'sum', year: 'Date', yearBox: '', decimals: 1 },
];

const CHARTS: (YearKpiSpec & { visual: 'column' | 'line' })[] = [
  { ...KPIS[0], title: 'Seedlings by year', visual: 'column' },
  { ...KPIS[1], title: 'Healthy % by year', visual: 'line' },
  { ...KPIS[7], title: 'Plants planted by year', visual: 'column' },
];

const clean = (text: string | undefined | null) => (text ?? '').trim().toLowerCase();

function find(sheet: SheetWithRows, name: string, box?: string): Column | undefined {
  return sheet.columns.find(
    (column) =>
      clean(column.name) === clean(name) &&
      (box === undefined ? true : box === '' ? !column.box : clean(column.box).startsWith(clean(box))),
  );
}

interface YearTile {
  title: string;
  value: string;
  note: string;
  trend: ChartPoint[];
}

@Component({
  selector: 'app-chili-dashboard',
  imports: [KpiChart],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="canvas">
      <div class="tiles">
        @for (tile of tiles(); track tile.title; let i = $index) {
          <article class="tile" [style.--i]="i">
            <h3>{{ tile.title }}</h3>
            <div class="body">
              <span class="value">{{ tile.value }}</span>
              <span class="note">{{ tile.note }}</span>
              <svg class="trend" viewBox="0 0 100 40" preserveAspectRatio="none" aria-hidden="true">
                @if (tile.trend.length >= 2) {
                  <defs>
                    <linearGradient [attr.id]="'fade-' + $index" x1="0" x2="0" y1="0" y2="1">
                      <stop offset="0%" stop-color="#118DFF" stop-opacity="0.22" />
                      <stop offset="100%" stop-color="#118DFF" stop-opacity="0" />
                    </linearGradient>
                  </defs>
                  <path [attr.d]="area(tile.trend)" [attr.fill]="'url(#fade-' + $index + ')'" />
                }
                <path [attr.d]="line(tile.trend)" fill="none" stroke="#118DFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke" />
              </svg>
            </div>
          </article>
        }
      </div>
      @if (charts().length) {
        <div class="charts">
          @for (chart of charts(); track chart.title; let i = $index) {
            <article class="tile chart" [style.--i]="i + 6">
              <h3>{{ chart.title }}</h3>
              <app-kpi-chart [points]="chart.points" [visual]="chart.visual" [label]="chart.title" />
            </article>
          }
        </div>
      }
    </div>
  `,
  styles: `
    @media (prefers-reduced-motion: no-preference) { .tile { animation: itemIn 420ms var(--ease) both; animation-delay: calc(var(--i, 0) * 45ms); } }
    /* As the system's KPI page: soft white cards straight on the page, no grey canvas. */
    .canvas { display: flex; flex-direction: column; gap: 12px; }
    .tiles { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; }
    .tile {
      container-type: inline-size;
      display: flex; flex-direction: column; min-width: 0; height: 176px; padding: 18px 22px 14px;
      background: var(--surface); border: var(--hairline) solid var(--border);
      border-radius: var(--radius-lg); box-shadow: var(--shadow-card);
    }
    h3 { font-size: 0.9375rem; font-weight: 400; color: var(--text-muted); letter-spacing: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .body { flex: 1; min-height: 0; display: flex; flex-direction: column; align-items: flex-start; justify-content: flex-end; gap: 6px; }
    .value { font-size: max(16px, min(42px, 10cqw)); line-height: 1.05; font-weight: 700; letter-spacing: -0.03em; font-variant-numeric: tabular-nums; color: var(--text); }
    .note { font-size: 0.8125rem; color: var(--text-muted); }
    .trend { display: block; width: 100%; flex: 1; min-height: 24px; max-height: 56px; margin-top: 2px; }
    .charts { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
    .tile.chart { height: auto; min-height: 0; padding: 18px 22px 16px; gap: 10px; }
    .tile.chart h3 { font-weight: 600; color: var(--text); }
  `,
})
export class ChiliDashboard {
  readonly sheets = input.required<readonly SheetWithRows[]>();
  readonly formulas = input.required<WorkbookFormulas>();

  private byKey(key: string) {
    return this.sheets().find((sheet) => sheet.templateKey === key);
  }

  /** A KPI's value per year (its trend, oldest first), or null: its table or column isn't there. */
  private years(spec: YearKpiSpec): { trend: ChartPoint[]; whole: number | null } | null {
    const sheet = this.byKey(spec.table);
    if (!sheet) return null;
    const column = spec.column ? find(sheet, spec.column, spec.box) : null;
    if (spec.column && !column) return null;
    const year = find(sheet, spec.year, spec.yearBox);
    const values = columnValues(this.formulas(), sheet, column?.key ?? '');
    if (!values) return null;
    const whole = reduceValues(values, spec.aggregate);
    if (!year) return { trend: [], whole };
    const dates = columnValues(this.formulas(), sheet, year.key) ?? [];
    const groups = new Map<string, typeof values>();
    dates.forEach((date, index) => {
      const iso = typeof date === 'string' ? date.slice(0, 10) : '';
      if (!isIsoDate(iso)) return;
      const key = iso.slice(0, 4);
      groups.set(key, [...(groups.get(key) ?? []), values[index]]);
    });
    // A year with nothing to average (or min / max) isn't a point; a sum's is 0.
    const trend = [...groups.entries()]
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([label, items]) => ({ label, value: reduceValues(items, spec.aggregate) }))
      .filter((point): point is ChartPoint => point.value !== null);
    return { trend, whole };
  }

  readonly tiles = computed<YearTile[]>(() =>
    KPIS.flatMap((spec) => {
      const found = this.years(spec);
      if (!found) return [];
      const { trend, whole } = found;
      const last = trend.at(-1);
      const before = trend.length > 1 ? trend[trend.length - 2] : null;
      // As the system's KPI: the latest year, next to the year before.
      const value = last ? last.value : whole;
      const hasRows = !!this.byKey(spec.table)?.rows.length;
      let note = hasRows ? 'No values yet' : 'No rows yet';
      if (before && last && before.value) {
        const change = ((last.value - before.value) / Math.abs(before.value)) * 100;
        note = `${change >= 0 ? '▲' : '▼'} ${Math.abs(change).toFixed(1)}% vs ${before.label}`;
      } else if (last) note = last.label;
      else if (whole !== null && hasRows) note = 'All rows (no dates yet)';
      return [{ title: spec.title, value: formatNumber(value, spec.decimals ?? 0), note, trend }];
    }),
  );

  readonly charts = computed(() =>
    CHARTS.flatMap((spec) => {
      const found = this.years(spec);
      return found ? [{ title: spec.title, points: found.trend, visual: spec.visual }] : [];
    }),
  );

  /** The trend's line across the tile (flat along the bottom with under two years). */
  line(trend: ChartPoint[]) {
    return this.path(trend, false);
  }

  area(trend: ChartPoint[]) {
    return this.path(trend, true);
  }

  private path(trend: ChartPoint[], closed: boolean) {
    const points = trend.length >= 2 ? trend : [{ value: 0 }, { value: 0 }];
    const values = points.map((point) => point.value);
    const low = Math.min(...values);
    const high = Math.max(...values);
    const room = (high - low || Math.abs(high) || 1) * 0.2;
    const [min, max] = [low - room * 1.5, high + room];
    const y = (value: number) => (trend.length >= 2 ? 40 - ((value - min) / (max - min)) * 38 : 38);
    const xy = points.map((point, index) => ({ x: (index / (points.length - 1)) * 100, y: y(point.value) }));
    // A smooth curve through the points (Catmull-Rom as Béziers), as the system's trend.
    let line = `M ${xy[0].x},${xy[0].y.toFixed(2)}`;
    for (let i = 0; i < xy.length - 1; i += 1) {
      const [p0, p1, p2, p3] = [xy[Math.max(0, i - 1)], xy[i], xy[i + 1], xy[Math.min(xy.length - 1, i + 2)]];
      const c1 = { x: p1.x + (p2.x - p0.x) / 6, y: p1.y + (p2.y - p0.y) / 6 };
      const c2 = { x: p2.x - (p3.x - p1.x) / 6, y: p2.y - (p3.y - p1.y) / 6 };
      line += ` C ${c1.x.toFixed(2)},${c1.y.toFixed(2)} ${c2.x.toFixed(2)},${c2.y.toFixed(2)} ${p2.x.toFixed(2)},${p2.y.toFixed(2)}`;
    }
    return closed ? `${line} L 100,40 L 0,40 Z` : line;
  }
}

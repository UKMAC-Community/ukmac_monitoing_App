//! The chili template: the tables a new chili MAC starts with — the
//! server's chili navs (`guidelines/templates.py`) and the tables that were
//! fixed there (Chili Varieties, Nursery Batches, Zone Records), every one
//! an ordinary sheet here: renamed, re-columned or deleted at will.
//!
//! Column names are the server's Excel template headers, so a template
//! already filled from the server imports as it is.

use crate::model::Column;

pub struct TemplateSheet {
    pub key: &'static str,
    pub title: &'static str,
    pub heading: &'static str,
    pub icon: &'static str,
    pub about: &'static str,
    pub columns: Vec<Column>,
}

fn col(name: &str, col_type: &str) -> Column {
    Column::new(name, col_type)
}

fn text(name: &str) -> Column {
    col(name, "text")
}

fn number(name: &str) -> Column {
    col(name, "number")
}

fn date(name: &str) -> Column {
    col(name, "date")
}

fn required(mut column: Column) -> Column {
    column.required = true;
    column
}

fn link(name: &str, source: &str) -> Column {
    let mut column = col(name, "link");
    column.source = Some(source.into());
    column
}

fn formula(name: &str, formula: &str) -> Column {
    let mut column = col(name, "formula");
    column.formula = Some(formula.into());
    column
}

fn in_group(mut column: Column, group: &str) -> Column {
    column.group = Some(group.into());
    column
}

fn with_unit(mut column: Column, unit: &str) -> Column {
    column.unit = Some(unit.into());
    column
}

fn in_box(columns: Vec<Column>, box_name: &str) -> Vec<Column> {
    columns
        .into_iter()
        .map(|mut column| {
            column.box_name = Some(box_name.into());
            column
        })
        .collect()
}

const ZONE_SOURCE: &str = "'Zones'[Plot]";
const VARIETY_SOURCE: &str = "'Chili Varieties'[Variety name]";
const BATCH_SOURCE: &str = "'Nursery Batches'[Batch #]";

/// A row's Date and Zone, as the server's feature tables start.
fn date_zone() -> Vec<Column> {
    vec![date("Date"), link("Zone", ZONE_SOURCE)]
}

// ---------------------------------------------------------------- QA/QC

/// Each stage's day after transplant, as the old QC sheet dated it from
/// the planting date; the first three shown 3 days ahead.
fn stage_days(number: u32) -> u32 {
    match number {
        1 => 0,
        2 => 7,
        3 => 30,
        4 => 45,
        5 => 60,
        6..=9 => 75,
        _ => 150,
    }
}

fn stage_box(number: u32, title: &str, target: Option<&str>) -> String {
    match target {
        Some(target) => format!("{number} · {title} ({target})"),
        None => format!("{number} · {title}"),
    }
}

/// A stage of the approved 10-stage QC form, a box of its own: its Date
/// and Days after transplant worked out from the row's Date (the
/// planting), then the stage's measures.
fn stage(number: u32, title: &str, target: Option<&str>, measures: Vec<Column>) -> Vec<Column> {
    let box_name = stage_box(number, title, target);
    let days = stage_days(number);
    let ahead = if number <= 3 { "+3" } else { "" };
    let mut columns = vec![
        formula(
            "Date",
            &format!(r#"=IF([Date]="","",IF([Date]+{days}>TODAY(){ahead},"",[Date]+{days}))"#),
        ),
        formula(
            "Days after transplant",
            &format!(r#"=IF([{box_name} › Date]="","",DAYS([{box_name} › Date],[Date]))"#),
        ),
    ];
    columns.extend(measures);
    in_box(columns, &box_name)
}

fn count(name: &str, group: &str) -> Column {
    in_group(number(name), group)
}

fn count_unit(name: &str, group: &str, unit: &str) -> Column {
    with_unit(count(name, group), unit)
}

const LEAF: &str = "Seedling Leaf Stage (No.)";
const VIGOR: &str = "Seedling Health / Vigor (No.)";
const AVERAGE: &str = "Plant average";
const YIELD: &str = "Cumulative Yield";
const REJECTED: &str = "Rejected (kg)";
const REJECTS: [&str; 6] = ["Pest damage", "Disease", "Too small", "Deformed", "Rot", "Color reject"];

fn qa_qc_columns() -> Vec<Column> {
    let harvest_box = stage_box(8, "Harvest", Some("75–150 DAT"));
    let end_box = stage_box(10, "End of Cycles", None);
    let rejected_kg = REJECTS
        .iter()
        .map(|name| format!("[{harvest_box} › {REJECTED} › {name}]"))
        .collect::<Vec<_>>()
        .join(",");

    let mut columns = vec![required(date("Date")), required(link("Zone", ZONE_SOURCE))];
    columns.extend(in_box(vec![text("Plant batch"), text("Block")], "QC record"));
    columns.extend(stage(
        1,
        "Transplant",
        Some("0 DAT"),
        vec![
            count("4–5, good", LEAF),
            count("3, >5", LEAF),
            count("Disease", LEAF),
            count("Healthy", VIGOR),
            count("Medium", VIGOR),
            count("Wilt", VIGOR),
        ],
    ));
    columns.extend(stage(
        2,
        "Establishment",
        Some("7 DAT"),
        vec![
            count("Live plant", "Plant Survival (No.)"),
            // 20 plants a block: those not alive (the old sheet's =20-N7).
            in_group(
                formula("Dead plant", r#"=IF([Live plant]="","",20-[Live plant])"#),
                "Plant Survival (No.)",
            ),
            count("Upright plants", "New Growth (No.)"),
            count("Uneven / Wilt", "New Growth (No.)"),
        ],
    ));
    columns.extend(stage(
        3,
        "Vegetative",
        Some("30 DAT"),
        vec![
            count("Vigor score (1–5)", AVERAGE),
            count_unit("Plant height", AVERAGE, "cm"),
            count_unit("Canopy A, widest", AVERAGE, "cm"),
            count_unit("Canopy B, across", AVERAGE, "cm"),
            count("Branches", AVERAGE),
        ],
    ));
    columns.extend(stage(
        4,
        "Flowering",
        Some("45 DAT"),
        vec![
            in_group(col("Plant flowering", "percentage"), AVERAGE),
            count("Flowers per plant", AVERAGE),
        ],
    ));
    columns.extend(stage(
        5,
        "Fruit set",
        Some("60 DAT"),
        vec![
            count("Upright", "Fruit Orientation (No.)"),
            count("Mixed", "Fruit Orientation (No.)"),
            count("Different", "Fruit Orientation (No.)"),
            count("True-to-type", "Fruit Shape (No.)"),
            count("Variability", "Fruit Shape (No.)"),
            count("Off-type", "Fruit Shape (No.)"),
            count("Young fruits per plant", AVERAGE),
        ],
    ));
    columns.extend(stage(
        6,
        "First Harvest",
        Some("75 DAT"),
        vec![
            date("Harvest date"),
            count_unit("Fruit length", AVERAGE, "cm"),
            count_unit("Fruit diameter", AVERAGE, "cm"),
        ],
    ));
    columns.extend(stage(
        7,
        "Maturity",
        Some("75 DAT+"),
        vec![
            count("Green", "Fruit Color (No.)"),
            count("Turning", "Fruit Color (No.)"),
            count("Red", "Fruit Color (No.)"),
        ],
    ));
    let mut harvest = vec![
        count_unit("Total", "Marketable Fruit (kg)", "kg"),
        count_unit("Marketable", "Marketable Fruit (kg)", "kg"),
    ];
    harvest.extend(REJECTS.iter().map(|name| count_unit(name, REJECTED, "kg")));
    // Every reason entered, their sum (the old sheet's Total (kg)).
    harvest.push(with_unit(
        in_group(
            formula(
                "Total",
                &format!(r#"=IF(COUNT({rejected_kg})<6,"",SUM({rejected_kg}))"#),
            ),
            REJECTED,
        ),
        "kg",
    ));
    harvest.extend([
        count("Harvest rounds", YIELD),
        count_unit("Harvested", YIELD, "kg"),
        count("Total plant", YIELD),
    ]);
    columns.extend(stage(8, "Harvest", Some("75–150 DAT"), harvest));
    columns.extend(stage(
        9,
        "Plant Health",
        Some("75–150 DAT"),
        vec![
            count("0–70 DAT", "Pest / Disease per block (No.)"),
            count("0–150 DAT", "Pest / Disease per block (No.)"),
        ],
    ));
    columns.extend(stage(
        10,
        "End of Cycles",
        None,
        vec![
            count("Harvest rounds", YIELD),
            count_unit("Harvested", YIELD, "kg"),
            count("Total plant", YIELD),
            // The final rounds' kilos per plant.
            with_unit(
                in_group(
                    formula(
                        "Yield per plant",
                        &format!(
                            r#"=IF(OR([{end_box} › Harvested]="",[{end_box} › Total plant]="",[{end_box} › Total plant]=0),"",[{end_box} › Harvested]/[{end_box} › Total plant])"#
                        ),
                    ),
                    YIELD,
                ),
                "kg",
            ),
        ],
    ));
    columns
}

// -------------------------------------------------------------- Nursery

fn nursery_batch_columns() -> Vec<Column> {
    let damage = r#"[Stem rot],[Leaf rot],[Smaller],[Disease],[Physical damage]"#;
    vec![
        text("Batch #"),
        required(link("Plant type", VARIETY_SOURCE)),
        text("Origin"),
        date("Supply date"),
        required(number("Total number")),
        number("Healthy"),
        number("Stem rot"),
        number("Leaf rot"),
        number("Smaller"),
        number("Disease"),
        number("Physical damage"),
        formula(
            "Not healthy",
            &format!(r#"=IF(COUNT({damage})=0,"",SUM({damage}))"#),
        ),
        formula(
            "Healthy %",
            r#"=IF(OR([Healthy]="",[Total number]="",[Total number]=0),"",ROUND([Healthy]/[Total number]*100,2))"#,
        ),
        date("Planting start date"),
        date("Planting end date"),
        number("Min height (cm)"),
        number("Min height (%)"),
        number("Max height (cm)"),
        number("Max height (%)"),
        number("Mean height (cm)"),
        number("Mean height (%)"),
        text("Leaf #/plant"),
        text("Fertilizer name"),
        text("Fertilizer concentration"),
        text("Pesticide name"),
        text("Pesticide concentration"),
        number("Watering (times/day)"),
        text("Note"),
    ]
}

fn zone_record_columns() -> Vec<Column> {
    vec![
        required(link("Zone plot", ZONE_SOURCE)),
        required(date("Record date")),
        number("Day number"),
        number("Plant count"),
        link("Plant type", VARIETY_SOURCE),
        link("Nursery batch", BATCH_SOURCE),
        text("Status"),
        date("Replant date"),
        number("Replant count"),
        number("Dead plant"),
        text("Note"),
    ]
}

/// A log the farm fills in day by day: Date, Zone, then what it records.
fn zone_log(extra: Vec<Column>) -> Vec<Column> {
    let mut columns = date_zone();
    columns.extend(extra);
    columns.push(text("Note"));
    columns
}

pub fn chili_template() -> Vec<TemplateSheet> {
    vec![
        TemplateSheet {
            key: "zones",
            title: "Zones",
            heading: "Setup",
            icon: "map",
            about: "The farm's zones and plots. Every table's Zone picks a Plot from here.",
            columns: vec![
                required(text("Zone")),
                required(text("Plot")),
                number("Plant capacity"),
                text("Note"),
                number("Zone number"),
                number("Row"),
                number("Column"),
                text("Plot status"),
                text("Status name"),
                text("Outline"),
            ],
        },
        TemplateSheet {
            key: "zone-measurement",
            title: "Zone Measurement",
            heading: "Setup",
            icon: "ruler",
            about: "Each plot's measured size: planned and actual plots, width and length, and the area they make.",
            columns: vec![
                link("Zone plot", ZONE_SOURCE),
                text("Planned plot"),
                text("Actual plot"),
                number("Number each plot"),
                text("Actual planting plot"),
                with_unit(number("Width"), "m"),
                with_unit(number("Length"), "m"),
                with_unit(formula("Area", r#"=IF(OR([Width]="",[Length]=""),"",[Width]*[Length])"#), "m²"),
                text("Note"),
            ],
        },
        TemplateSheet {
            key: "chili-varieties",
            title: "Chili Varieties",
            heading: "Nursery",
            icon: "sprout",
            about: "The chili varieties the farm grows. Nursery batches and zone records pick their Plant type from here.",
            columns: vec![
                required(text("Variety name")),
                text("Plant name"),
                text("Plant type"),
                text("Origin"),
                text("Description"),
            ],
        },
        TemplateSheet {
            key: "nursery-batches",
            title: "Nursery Batches",
            heading: "Nursery",
            icon: "seedling",
            about: "Each nursery batch: how many seedlings, how healthy, their height and care before planting.",
            columns: nursery_batch_columns(),
        },
        TemplateSheet {
            key: "zone-records",
            title: "Zone Records",
            heading: "Planting",
            icon: "clipboard",
            about: "Plant progress by zone plot: plants planted, replanted and dead, and how they're growing.",
            columns: zone_record_columns(),
        },
        TemplateSheet {
            key: "soil-preparation",
            title: "Soil Preparation",
            heading: "Planting",
            icon: "shovel",
            about: "Record how each zone's soil is prepared before planting — ploughing, beds, compost and soil tests.",
            columns: zone_log(vec![]),
        },
        TemplateSheet {
            key: "irrigation",
            title: "Irrigation",
            heading: "Planting",
            icon: "droplets",
            about: "Plan and log watering for each zone: when, how long and how much.",
            columns: zone_log(vec![]),
        },
        TemplateSheet {
            key: "fertigation",
            title: "Fertigation",
            heading: "Planting",
            icon: "flask",
            about: "Log the fertilizer given through the irrigation water — mix, dose and date — for each zone.",
            columns: zone_log(vec![]),
        },
        TemplateSheet {
            key: "pruning",
            title: "Pruning",
            heading: "Planting",
            icon: "scissors",
            about: "Track pruning rounds across the zones and who did them.",
            columns: zone_log(vec![]),
        },
        TemplateSheet {
            key: "pesticides",
            title: "Pesticides",
            heading: "Planting",
            icon: "spray",
            about: "Record every spray: the product, dose, target pest and the safe-to-harvest date.",
            columns: zone_log(vec![]),
        },
        TemplateSheet {
            key: "harvest",
            title: "Harvest",
            heading: "Planting",
            icon: "wheat",
            about: "Record what each zone harvests, round by round, by weight and grade.",
            columns: zone_log(vec![]),
        },
        TemplateSheet {
            key: "qa-qc-management",
            title: "QA/QC Management",
            heading: "QA/QC",
            icon: "check",
            about: "Quality checks on the crop, plot by plot and stage by stage: the approved 10-stage QC form, a row per QC record (its plot the row's Zone, its planting the row's Date).",
            columns: qa_qc_columns(),
        },
        TemplateSheet {
            key: "planting-date",
            title: "Planting Date",
            heading: "QA/QC",
            icon: "calendar",
            about: "Each zone's planting date and expected harvest window (75–150 days after transplant).",
            columns: vec![
                required(link("Zone", ZONE_SOURCE)),
                required(date("Planting date")),
                formula(
                    "Harvest from",
                    r#"=IF([Planting date]="","",[Planting date]+75)"#,
                ),
                formula(
                    "Harvest to",
                    r#"=IF([Planting date]="","",[Planting date]+150)"#,
                ),
                text("Note"),
            ],
        },
        TemplateSheet {
            key: "inventory",
            title: "Inventory Management",
            heading: "Inventory",
            icon: "package",
            about: "The stock in the greenhouse: stock in and stock out by quantity.",
            columns: vec![
                date("Date"),
                required(text("Item")),
                number("Stock in"),
                number("Stock out"),
                text("Unit"),
                text("Note"),
            ],
        },
        TemplateSheet {
            key: "finance",
            title: "Finance & Accounting",
            heading: "Operational",
            icon: "wallet",
            about: "The project's income and costs: purchases, sales and the accounts behind them.",
            columns: vec![
                date("Date"),
                required(text("Description")),
                text("Category"),
                number("Income"),
                number("Cost"),
                text("Note"),
            ],
        },
    ]
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashSet;

    #[test]
    fn qa_qc_is_the_old_form_plus_date_and_zone() {
        let columns = qa_qc_columns();
        // The server's 70 columns (23 formulas), with the row's Date and Zone in front.
        assert_eq!(columns.len(), 72);
        assert_eq!(columns.iter().filter(|c| c.col_type == "formula").count(), 23);
        let boxes: HashSet<_> = columns.iter().filter_map(|c| c.box_name.clone()).collect();
        assert_eq!(boxes.len(), 11);
        assert_eq!(columns[0].name, "Date");
        assert_eq!(columns[1].source.as_deref(), Some("'Zones'[Plot]"));
    }

    #[test]
    fn every_formula_names_columns_the_table_has() {
        for sheet in chili_template() {
            let names: HashSet<String> = sheet
                .columns
                .iter()
                .flat_map(|c| {
                    let mut names = vec![c.name.clone()];
                    if let Some(b) = &c.box_name {
                        names.push(format!("{b} › {}", c.name));
                        if let Some(g) = &c.group {
                            names.push(format!("{b} › {g} › {}", c.name));
                        }
                    }
                    names
                })
                .collect();
            for column in sheet.columns.iter().filter(|c| c.col_type == "formula") {
                let formula = column.formula.as_deref().unwrap();
                let mut rest = formula;
                while let Some(start) = rest.find('[') {
                    let end = rest[start..].find(']').unwrap() + start;
                    let name = &rest[start + 1..end];
                    assert!(names.contains(name), "{}: {} names [{}]", sheet.title, column.name, name);
                    rest = &rest[end + 1..];
                }
            }
        }
    }

    #[test]
    fn links_point_at_template_tables() {
        let sheets = chili_template();
        for sheet in &sheets {
            for column in sheet.columns.iter().filter(|c| c.col_type == "link") {
                let source = column.source.as_deref().unwrap();
                let table = source.trim_start_matches('\'').split("'[").next().unwrap();
                let name = source.split("'[").nth(1).unwrap().trim_end_matches(']');
                let target = sheets.iter().find(|s| s.title == table).expect(table);
                assert!(target.columns.iter().any(|c| c.name == name), "{source}");
            }
        }
    }
}

#[cfg(test)]
mod dump {
    /// `TEMPLATE_OUT=file cargo test dump_template -- --ignored`: the template as JSON, to check its formulas in the app's engine.
    #[test]
    #[ignore]
    fn dump_template() {
        let sheets: Vec<_> = super::chili_template()
            .into_iter()
            .map(|sheet| {
                let mut columns = sheet.columns;
                for (index, column) in columns.iter_mut().enumerate() {
                    column.key = format!("c{}", index + 1);
                }
                serde_json::json!({ "key": sheet.key, "title": sheet.title, "heading": sheet.heading, "icon": sheet.icon, "about": sheet.about, "columns": columns })
            })
            .collect();
        std::fs::write(std::env::var("TEMPLATE_OUT").unwrap(), serde_json::to_string_pretty(&sheets).unwrap()).unwrap();
    }
}
